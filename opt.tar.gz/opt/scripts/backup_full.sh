#!/bin/bash

#Validacion
if [[ $1 == "-h" || $# -ne 2 ]]; then
    show_help
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

#Ver origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen '$ORIGEN' no existe o no está montado."
    exit 1
fi

#Ver destino
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino '$DESTINO' no existe o no está montado."
    exit 1
fi

#Nombre
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

#Compressor
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $DESTINO/$NOMBRE_BACKUP"
else
    echo "Error al realizar el backup."
    exit 1
fi

#!/bin/bash

#Ayuda
function show_help {
    echo "Uso: $0 origen destino"
    echo "Ejemplo: $0 /etc /backup_dir"
    echo "El script realiza un backup completo del directorio origen en el destino con formato de nombre: origen_bkp_YYYYMMDD.tar.gz"
    echo "Opciones:"
    echo "  -h    Muestra esta ayuda"
    exit 0
}

#Validación
if [[ $1 == "-h" || $# -ne 2 ]]; then
    show_help
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

#Ver origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen '$ORIGEN' no existe o no está montado."
    exit 1
fi

#Ver destino
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino '$DESTINO' no existe o no está montado."
    exit 1
fi

#Nombre
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

#Backup
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"
if [[ $? -eq 0 ]]; then
    echo "Backup exitoso: $DESTINO/$NOMBRE_BACKUP"
else
    echo "Error al realizar el backup."
    exit 1
fi